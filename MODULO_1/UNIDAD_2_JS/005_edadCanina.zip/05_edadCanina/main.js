let edadPerro = parseInt(prompt("Introduce la edad del perro"));
document.write(`Número introducido: ${edadPerro}`);
const factorHumano = 7;
let multiplicacion = edadPerro * factorHumano;
document.write(`<br>\n edad del perro en Humano: ${multiplicacion}`);