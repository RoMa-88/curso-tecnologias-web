let num1 = parseInt(prompt("Introduce un número"));
document.write(`Número introducido: ${num1}`);
let num2 = parseInt(prompt("Intrpoduce otro número"));
document.write(`<br>\n Número introducido: ${num2}`);
let suma = num1 + num2;
document.write(`<br>\n suma: ${suma}`);