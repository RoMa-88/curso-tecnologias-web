const COLORS = ["#fff2", "#fff4", "#fff7", "#fffc"];

const generateSpaceLayer = (size, selector, totalStars, duration) => {
    const layer = [];
    for (let i = 0; i < totalStars; i++) {
        const color = COLORS[~~(Math.random() * COLORS.length)];
        const x = Math.floor(Math.random() * 100);
        const y = Math.floor(Math.random() * 100);
        layer.push(`${x}vw ${y}vh 0 ${color}, ${x}vw ${y + 100}vh 0 ${color}`);
    }
    const container = document.querySelector(selector);
    container.style.setProperty("--size", size);
    container.style.setProperty("--duration", duration);
    container.style.setProperty("--space-layer", layer.join(","));
};

// Genera capas de estrellas de diferentes tamaños y velocidades
generateSpaceLayer("2px", ".space-1", 250, "25s");
generateSpaceLayer("3px", ".space-2", 100, "20s");
generateSpaceLayer("6px", ".space-3", 25, "15s");

// Genera estrellas fugaces
const generateShootingStars = () => {
    const shootingStars = [];
    for (let i = 0; i < 5; i++) { // Número de estrellas fugaces
        const x = Math.floor(Math.random() * 100);
        const y = Math.floor(Math.random() * 100);
        shootingStars.push(`${x}vw ${y}vh 0 #fff`);
    }
    const container = document.querySelector(".shooting-stars");
    container.style.setProperty("--shooting-stars-layer", shootingStars.join(","));
};

// Llama a la función cada cierto tiempo para generar estrellas fugaces
setInterval(generateShootingStars, 5000);
